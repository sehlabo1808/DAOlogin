package com.example.daologin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextWatcher;

import com.example.daologin.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        binding.username.addTextChangeListener(new TextWatcher()){
            @Override
                    public  void beforeTextChangeD(CharSequence charSequence, int i, int i1, int i2 ){

                @Override
                        public  void on
            }

        }
    }
}